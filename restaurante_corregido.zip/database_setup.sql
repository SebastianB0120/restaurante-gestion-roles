-- Script de creación de base de datos para SQL Server
-- Restaurante Pasta La Vista - Sistema de Roles

CREATE DATABASE restaurante_502;
GO
USE restaurante_502;
GO

-- Tabla de Clientes
CREATE TABLE Cliente (
    id INT PRIMARY KEY IDENTITY(1,1),
    nombre NVARCHAR(100) NOT NULL,
    telefono NVARCHAR(20),
    correo NVARCHAR(100) UNIQUE
);

-- Tabla de Empleados con Roles
CREATE TABLE Empleado (
    id INT PRIMARY KEY IDENTITY(1,1),
    nombre NVARCHAR(100) NOT NULL,
    cargo NVARCHAR(50) CHECK (cargo IN ('Administrador', 'Mesero', 'Cajero')),
    telefono NVARCHAR(20),
    correo NVARCHAR(100) UNIQUE,
    user_id INT -- Relación con la tabla de usuarios de Django
);

-- Tabla de Mesas
CREATE TABLE Mesa (
    id INT PRIMARY KEY IDENTITY(1,1),
    numero_mesa INT UNIQUE NOT NULL,
    capacidad INT NOT NULL,
    estado_mesa NVARCHAR(20) DEFAULT 'Disponible' CHECK (estado_mesa IN ('Disponible', 'Ocupada', 'Reservada'))
);

-- Tabla de Platos
CREATE TABLE Plato (
    id INT PRIMARY KEY IDENTITY(1,1),
    nombre_plato NVARCHAR(100) NOT NULL,
    descripcion NVARCHAR(MAX),
    precio DECIMAL(10,2) NOT NULL,
    categoria NVARCHAR(50),
    disponible BIT DEFAULT 1
);

-- Tabla de Órdenes
CREATE TABLE OrdenRestaurante (
    id INT PRIMARY KEY IDENTITY(1,1),
    cliente_id INT FOREIGN KEY REFERENCES Cliente(id),
    empleado_id INT FOREIGN KEY REFERENCES Empleado(id),
    mesa_id INT FOREIGN KEY REFERENCES Mesa(id),
    fecha_hora DATETIME DEFAULT GETDATE(),
    estado_orden NVARCHAR(20) DEFAULT 'Activa' CHECK (estado_orden IN ('Activa', 'En preparación', 'Entregada', 'Facturada', 'Cancelada')),
    total DECIMAL(10,2) DEFAULT 0
);

-- Detalle de Órdenes
CREATE TABLE Detalle_Orden (
    id INT PRIMARY KEY IDENTITY(1,1),
    orden_id INT FOREIGN KEY REFERENCES OrdenRestaurante(id),
    plato_id INT FOREIGN KEY REFERENCES Plato(id),
    cantidad INT NOT NULL,
    precio_unitario DECIMAL(10,2),
    subtotal DECIMAL(10,2)
);

-- Tabla de Facturas
CREATE TABLE Factura (
    id INT PRIMARY KEY IDENTITY(1,1),
    orden_id INT UNIQUE FOREIGN KEY REFERENCES OrdenRestaurante(id),
    fecha_factura DATETIME DEFAULT GETDATE(),
    subtotal DECIMAL(10,2) NOT NULL,
    impuesto DECIMAL(10,2) NOT NULL,
    total_factura DECIMAL(10,2) NOT NULL,
    metodo_pago NVARCHAR(30) CHECK (metodo_pago IN ('Efectivo', 'Tarjeta', 'Transferencia', 'Nequi', 'Daviplata'))
);
