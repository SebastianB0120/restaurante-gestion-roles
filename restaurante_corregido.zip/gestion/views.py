from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import AuthenticationForm
from .models import Cliente, Empleado, Mesa, Plato, Orden, Factura
from .forms import (
    ClienteForm,
    EmpleadoForm,
    MesaForm,
    PlatoForm,
    OrdenForm,
    FacturaForm,
)

# Funciones de verificación de roles
def es_administrador(user):
    return user.is_authenticated and hasattr(user, 'empleado') and user.empleado.cargo == 'Administrador'

def es_mesero(user):
    return user.is_authenticated and hasattr(user, 'empleado') and user.empleado.cargo == 'Mesero'

def es_cajero(user):
    return user.is_authenticated and hasattr(user, 'empleado') and user.empleado.cargo == 'Cajero'

def es_admin_o_mesero(user):
    return es_administrador(user) or es_mesero(user)

def es_admin_o_cajero(user):
    return es_administrador(user) or es_cajero(user)

# --- Autenticación ---
def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('inicio')
    else:
        form = AuthenticationForm()
    return render(request, 'registration/login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def inicio(request):
    context = {
        'total_clientes': Cliente.objects.count(),
        'total_empleados': Empleado.objects.count(),
        'total_mesas': Mesa.objects.count(),
        'total_platos': Plato.objects.count(),
        'total_ordenes': Orden.objects.count(),
        'total_facturas': Factura.objects.count(),
    }
    return render(request, 'gestion/inicio.html', context)

# --- Cliente (Admin) ---
@user_passes_test(es_administrador)
def cliente_lista(request):
    clientes = Cliente.objects.all()
    return render(request, 'gestion/cliente_lista.html', {'clientes': clientes})

@user_passes_test(es_administrador)
def cliente_crear(request):
    if request.method == 'POST':
        form = ClienteForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('cliente_lista')
    else:
        form = ClienteForm()
    return render(request, 'gestion/cliente_form.html', {'form': form, 'titulo': 'Crear cliente'})

# --- Empleado (Admin) ---
@user_passes_test(es_administrador)
def empleado_lista(request):
    empleados = Empleado.objects.all()
    return render(request, 'gestion/empleado_lista.html', {'empleados': empleados})

# --- Mesa (Admin y Mesero) ---
@user_passes_test(es_admin_o_mesero)
def mesa_lista(request):
    mesas = Mesa.objects.all()
    return render(request, 'gestion/mesa_lista.html', {'mesas': mesas})

# --- Plato (Admin y Mesero) ---
@user_passes_test(es_admin_o_mesero)
def plato_lista(request):
    platos = Plato.objects.all()
    return render(request, 'gestion/plato_lista.html', {'platos': platos})

# --- Orden (Admin y Mesero) ---
@user_passes_test(es_admin_o_mesero)
def orden_lista(request):
    ordenes = Orden.objects.select_related('cliente', 'empleado', 'mesa').all()
    return render(request, 'gestion/orden_lista.html', {'ordenes': ordenes})

@user_passes_test(es_admin_o_mesero)
def orden_crear(request):
    if request.method == 'POST':
        form = OrdenForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('orden_lista')
    else:
        form = OrdenForm()
    return render(request, 'gestion/orden_form.html', {'form': form, 'titulo': 'Crear orden'})

# --- Factura (Admin y Cajero) ---
@user_passes_test(es_admin_o_cajero)
def factura_lista(request):
    facturas = Factura.objects.select_related('orden').all()
    return render(request, 'gestion/factura_lista.html', {'facturas': facturas})

@user_passes_test(es_admin_o_cajero)
def factura_crear(request):
    if request.method == 'POST':
        form = FacturaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('factura_lista')
    else:
        form = FacturaForm()
    return render(request, 'gestion/factura_form.html', {'form': form, 'titulo': 'Crear factura'})
